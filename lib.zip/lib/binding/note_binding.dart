import 'package:get/get.dart';
import 'package:stateman/controllers/notes_controller.dart';

class NoteBinding implements Bindings {
  @override
  void dependencies() {
    Get.put(NotesController());
  }
}
