import 'package:get/get.dart';
import 'package:hive_flutter/adapters.dart';
import 'package:stateman/constant/const.dart';
import 'package:stateman/model/model_note.dart';

class NotesController extends GetxController {
  var listnotes = <NoteModel>[].obs;
  @override
  void onInit() {
    // TODO: implement onInit
    openBox();
    super.onInit();
  }

  void addNotes(NoteModel note) async {
    var box = await Hive.box(kNoteBox);
    await box.add(note);
    listnotes.add(note);
  }

  void deletNotes(int index) async {
    var box = await Hive.box(kNoteBox);
    box.deleteAt(index);
    listnotes.remove(index);
  }

  void editNotes(NoteModel newnote, int index) async {
    var box = await Hive.box(kNoteBox);
    await box.putAt(index, newnote);
    listnotes[index] = newnote;
    listnotes.refresh();
  }

  void openBox() async {
    var box = await Hive.openBox<NoteModel>(kNoteBox);
    listnotes.addAll(box.values);
  }
}
