import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stateman/controllers/notes_controller.dart';
import 'package:stateman/model/model_note.dart';
import 'package:stateman/widget/custom_bottomWidget.dart';
import 'package:stateman/widget/custom_textFiled.dart';

class CustomBottomSheet extends StatelessWidget {
  const CustomBottomSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(child: CustomBottomForm());
  }
}

//

class CustomBottomForm extends StatefulWidget {
  const CustomBottomForm({super.key});

  @override
  State<CustomBottomForm> createState() => _CustomBottomFormState();
}

class _CustomBottomFormState extends State<CustomBottomForm> {
  NotesController controller = Get.find();

  final GlobalKey<FormState> key = GlobalKey();
  AutovalidateMode auto = AutovalidateMode.disabled;
  String? title, subtitle;
  @override
  Widget build(BuildContext context) {
    return Form(
      key: key,
      autovalidateMode: auto,
      child: Column(
        children: [
          CustomTextFiled(
            onSave: (value) {
              title = value;
            },
            labl: 'Title',
            color: Colors.purple,
            hinttext: ' Enter  The  Title',
            colorborder: Colors.purple,
          ),
          CustomTextFiled(
            onSave: (value) {
              subtitle = value;
            },
            labl: 'Descrption ',
            color: Colors.purple,
            hinttext: ' Enter  The  Descrption',
            colorborder: Colors.purple,
            maxlines: 6,
          ),
          SizedBox(
            height: 30,
          ),
          CustomBottomWidget(
            text: 'Add Notes ',
            width: 190,
            color: Colors.purple,
            ontap: () {
              if (key.currentState!.validate()) {
                key.currentState!.save();
                var noteadd = NoteModel(
                    title: title!,
                    subtitle: subtitle!,
                    date: '7 7 2007',
                    color: 12);
                controller.addNotes(noteadd);
              } else {
                auto = AutovalidateMode.always;
                setState(() {});
              }
            },
          )
        ],
      ),
    );
  }
}
