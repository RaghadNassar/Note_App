import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stateman/controllers/notes_controller.dart';
import 'package:stateman/screens/edit_screen.dart';
import 'package:stateman/widget/custom_container_listtile.dart';

class NotesBody extends StatelessWidget {
  const NotesBody({super.key});

  @override
  Widget build(BuildContext context) {
    
    
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.only(top: 18),
        child: ListView.builder(
            itemCount: 12,
            itemBuilder: (context, index) {
              return GestureDetector(
                  onTap: () {
                    Get.to(EditScreen());
                  },
                  child: ContainerCoustomBody());
            }),
      ),
    );
  }
}
