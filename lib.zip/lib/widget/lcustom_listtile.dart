
import 'package:flutter/material.dart';

class ListTileCustom extends StatelessWidget {
  const ListTileCustom({super.key});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        'Flutter with Kok ',
        style: TextStyle(fontSize: 17, color: Colors.black),
      ),
      subtitle: Text(
        'Flutter is defecult  with gradel version ',
        style: TextStyle(fontSize: 14, color: Colors.black.withOpacity(0.5)),
      ),
      trailing: IconButton(
          onPressed: () {},
          icon: Icon(
            Icons.delete,
            color: Colors.red,
          )),
    );
  }
}