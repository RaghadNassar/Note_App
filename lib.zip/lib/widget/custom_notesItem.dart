import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:stateman/controllers/notes_controller.dart';
import 'package:stateman/widget/custom_appBar.dart';
import 'package:stateman/widget/custom_notesBody.dart';

class NotesItem extends StatelessWidget {
  const NotesItem({super.key});

  @override
  Widget build(BuildContext context) {
   // NotesController controller=  Get.put(NotesController());
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Column(
        children: [
          CustomAppBar(text: 'Notes App',icons: Icons.search,),
          NotesBody(),
        ],
      ),
    );
  }
}