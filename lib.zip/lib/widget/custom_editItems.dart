import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:stateman/widget/custom_appBar.dart';
import 'package:stateman/widget/custom_bottomWidget.dart';
import 'package:stateman/widget/custom_textFiled.dart';

class CustomEdititems extends StatelessWidget {
  const CustomEdititems({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        CustomAppBar(
          text: 'Edite Notes',
          icons: Icons.arrow_back,
          ontap: () {
            return Get.back();
          },
        ),
        Spacer(),
        CustomTextFiled(
          labl: 'Title',
          color: Colors.purple,
          hinttext: ' Enter  The  Title',
          colorborder: Colors.purple,
        ),
        CustomTextFiled(
          labl: 'Descrption ',
          color: Colors.purple,
          hinttext: ' Enter  The  Descrption',
          colorborder: Colors.purple,
          maxlines: 6,
        ),
        SizedBox(
          height: 30,
        ),
        CustomBottomWidget(
          text: 'Add Notes ',
          width: 190,
          color: Colors.purple,
        ),
        Spacer()
      ],
    );
  }
}
