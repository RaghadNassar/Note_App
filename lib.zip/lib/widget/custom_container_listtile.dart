import 'package:flutter/material.dart';
import 'package:stateman/widget/lcustom_listtile.dart';

class ContainerCoustomBody extends StatelessWidget {
  const ContainerCoustomBody({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 8, bottom: 8),
      padding: EdgeInsets.only(top: 14, left: 14, bottom: 14),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          ListTileCustom(),
          Padding(
            padding: const EdgeInsets.only(right: 36),
            child: Text(
              '20_10_2025',
              style: TextStyle(fontSize: 17, color: Colors.black),
            ),
          ),
        ],
      ),
    );
    ;
  }
}